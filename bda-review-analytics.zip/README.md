# Flipkart Product Review Analytics (BDA Mini Project)

Big Data Analytics mini project: analysing Flipkart product reviews with **PySpark**,
predicting review sentiment with **Spark MLlib**, storing the data in a **PostgreSQL star
schema**, and showing the results in a **Streamlit dashboard**.

![Architecture](docs/architecture.png)

## Tools used

| Tool | Used for |
|---|---|
| Apache Spark (PySpark) | Reading, cleaning and transforming the data (Bronze, Silver, Gold) |
| Spark SQL | Gold summary tables |
| Spark MLlib | Sentiment model (TF-IDF + Logistic Regression) |
| Apache Parquet | Storage format for the Bronze and Silver layers |
| Hive tables (Spark's built-in Hive support) | Partitioned Hive table and HiveQL-style queries, on one machine (no Hadoop cluster, no HDFS) |
| PostgreSQL | Data warehouse (star schema with dimension and fact tables) |
| Docker (docker compose) | Runs PostgreSQL |
| Python, Pandas | Glue code and exports |
| Streamlit, Plotly | Dashboard |
| GitHub Codespaces, Git | Development environment and teamwork |

Spark runs in local mode (one machine). The same code can run on a cluster.

## Pipeline

| Step | Script | What it does |
|---|---|---|
| 1. Bronze | `scripts/01_bronze.py` | Raw CSV to Parquet, no changes |
| 2. Silver | `scripts/02_silver.py` | Removes duplicates and broken rows, cleans price and text, adds sentiment, category, price band |
| 3. Gold | `scripts/03_gold.py` | Spark SQL summary tables in `data/gold/*.csv` |
| 4. Model | `scripts/04_model.py` | Trains the sentiment model, saves metrics and weights |
| 5. Warehouse | `scripts/05_warehouse.py` | Builds the star schema with Spark and loads it into PostgreSQL |
| 6. SQL analysis | `scripts/06_sql_report.py` | Runs 10 queries from `sql/analysis_queries.sql`, saves `docs/sql_results.txt` |
| 7. Benchmark | `scripts/07_benchmark.py` | Pandas vs Spark timing at two data sizes |
| 8. Hive tables | `scripts/08_hive_tables.py` | Stores Silver as a Hive table partitioned by category and queries it with Spark SQL |
| Dashboard | `dashboard/app.py` | Streamlit dashboard (reads only `data/gold/`) |

Warehouse tables: `dim_category`, `dim_product`, `dim_price_band`, `dim_sentiment`, `fact_reviews`
(see `sql/schema.sql`), plus the Gold tables as `gold_*`.

## How to run

Put `flipkart_product.csv` in `data/`, then from the repo root:

```bash
pip install -r requirements.txt          # Java is also needed for PySpark
bash run_pipeline.sh                     # steps 1 to 4
```

Warehouse (needs PostgreSQL):

```bash
docker compose up -d                     # starts PostgreSQL (user bda, password bda123, db reviews)
bash run_warehouse.sh                    # steps 5 and 6
```

If Docker is not available, install PostgreSQL directly instead of using docker compose:

```bash
sudo apt-get update && sudo apt-get install -y postgresql
sudo service postgresql start
sudo -u postgres psql -c "CREATE USER bda WITH PASSWORD 'bda123';" -c "CREATE DATABASE reviews OWNER bda;"
```

Optional steps and the dashboard:

```bash
python scripts/07_benchmark.py       # Pandas vs Spark timing
python scripts/08_hive_tables.py     # Hive table (needs data/silver, no PostgreSQL)
streamlit run dashboard/app.py
```

## For the dashboard teammate

Spark and PostgreSQL are **not** needed. The Gold tables are already in `data/gold/`:

```bash
pip install streamlit plotly pandas numpy
streamlit run dashboard/app.py
```

Edit `dashboard/app.py` for layout and design. If the pipeline is re-run, the Gold files
keep the same column names.

## Results (tested run)

- 189,874 raw rows, 164,982 after cleaning (24,862 duplicates removed)
- Sentiment (from star rating): about 76% positive, 8% neutral, 15% negative
- 3-class model: about 75% accuracy, F1 0.78 to 0.79
- Positive vs negative only: about 92% accuracy, F1 0.93
- Neutral reviews are the hardest class to predict
- Exact numbers change slightly between runs and machines (random train/test split). Use the numbers from your own run.

## Notes and limitations

- Data: Flipkart product reviews from Kaggle. Single platform, short reviews, no dates.
- The review title is not used as a model input because it is tied to the star rating.
- Categories are derived from product names with keyword rules, so a few products may be misfiled.
- Only about half of the review texts are unique, so accuracy may be slightly optimistic.
- Hive here means Spark's built-in Hive support on one machine. A real Hadoop cluster with HDFS is not used.
- Not included (out of scope for a mini project): Airflow scheduling, an API and user login.
- See `docs/report_checklist.md` for what to screenshot for the report.
